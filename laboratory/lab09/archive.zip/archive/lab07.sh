#!/bin/bash
HELL=Hello

LOCAL HELLO=World
echo $HELLO
}
function hello {


LOCAL HELLO=World
echo $HELLO
}
